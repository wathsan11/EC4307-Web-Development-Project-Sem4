package com.AtrSite.Siththam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiththamApplicationTests {

	@Test
	void contextLoads() {
	}

}
